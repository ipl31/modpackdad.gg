KEN — KOVAAK'S WEEK 1 (30 MIN/DAY)
==================================

Purpose
-------
This week is biased toward the weaknesses shown by your Voltaic S5.5 novice
benchmark: dynamic/linear clicking and moving-target click timing, while
maintaining your comparatively strong tracking.

How to install
--------------
Copy the seven .json files into your KovaaK's local Playlists folder:

  <Steam library>\steamapps\common\FPSAimTrainer\FPSAimTrainer\Saved\SaveGames\Playlists

Restart KovaaK's if it is already running. The playlists should appear under
Local Playlists.

How to run the week
-------------------
Mon: Dynamic Clicking
Tue: Linear + Static
Wed: Dynamic Technique
Thu: Switching + Tracking Maintenance
Fri: Dynamic + Linear
Sat: Fortnite Transfer
Sun: Weakness Check

The play counts total 30 runs/day. Most of these scenarios are approximately
one-minute challenge runs, so sessions should land near 30 minutes, but exact
duration can vary by scenario.

Technique priorities
--------------------
Pasu / Popcorn:
  Read target -> acquire -> brief confirmation -> click.
  Do not increase click rate by spamming misses.

Static:
  Fast initial movement -> brake -> micro-correct -> click.

Tracking:
  Stay relaxed and react to direction changes instead of predicting them.

Target switching:
  Flick -> micro-correct -> stabilize -> move to next target.

Sunday:
  Treat this as a diagnostic session, not a PB marathon. Record the best score
  if you want, but pay more attention to whether your typical run is improving.

Notes
-----
- This is Week 1 only. Do not change difficulty during the week just because
  of one unusually good or bad run.
- If a scenario name does not resolve on your install, search for the exact
  name in Online Scenarios, download it, then retry the playlist.

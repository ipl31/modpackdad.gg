# Review artifact contract, version 1

Use the accompanying JSON template as a stable envelope. Replace nulls when known, retain null for unknown values, and fill arrays with the row shapes below. Empty arrays mean no records, not a passed check. Use unique IDs within each array and reference them rather than duplicating evidence. All paths resolve from the active repository unless absolute. This is an editorial sidecar, not an executable render plan or the existing `review.json`/review receipt.

## Identity, timing, and freshness

`status` is `preliminary`, `reviewed`, or `stale`. `reviewed` means the stated review scope was completed; it never means publishing readiness. `scope` is `pre_edit`, `structural_revision`, or `targeted`. `based_on_review_id` links a targeted follow-up to an earlier report.

`input.kind` is `raw_candidate` or `current_edit`. Record the exact reviewed media even when the user supplied a directory. `input.sha256_status` is `computed`, `recorded_only`, or `unavailable`. Duration and timebase values require a supporting artifact; preserve rational stream timebase and frame rate if known. Do not confuse container duration with content duration or an appended hold. For a raw candidate, output timing stays null until an actual edit map exists.

Each `bindings` row is `{ "role": "strategy", "path": "...", "sha256": "...", "sha256_status": "computed" }`; include source, transcript, strategy, storyboard, EDL/render EDL and analytics used. Preserve a recovered source's original-recording offset separately in `timebase.source_clock_origin`; do not reinterpret excerpt-relative seconds as archive-relative seconds.

Each range has `{ "in": 0.0, "out": 1.0 }`, in seconds, start inclusive/end exclusive. Point observations use equal in/out. `source` ranges are relative to `input.source_path`; `output` ranges are relative to `input.path` for an edit. Findings locate the current version; proposed ranges belong only under the proposed plan. Map through the matching `render-edl.json` for rendered timing when available, otherwise `edl.json`/storyboard beats and note rounding uncertainty. Split observations crossing cuts into separate locations. Synthetic holds have no moving source range. Never map across a cut by adding one global offset.

`freshness.state` is `current`, `unverified`, or `stale`, supported by `reason`. Compare the binding hashes before reuse. If media is unavailable, identity based solely on recorded metadata remains unverified. A revised strategy does not establish a revised export. A changed source, story, or pacing requires a new review; targeted cosmetic checks record precisely which older findings remain applicable.

## Evidence and findings

`inspection` rows:

```json
{"id":"E1","kind":"transcript","artifact":"path/to/transcript.json","locator":"segments[4]","reviewer":"agent","performed":"read","ranges":[{"timebase":"source","in":12.0,"out":15.0}],"limitations":"ASR estimates; not listened"}
```

Kinds include `visual_playback`, `audio_listening`, `sampled_frames`, `transcript`, `source_context`, `metadata`, `technical_report`, and `analytics`. Record actual coverage; use `ranges: []` with a precise locator if timing is unknown. Full audiovisual playback needs both continuous visual and audio coverage, supported by actual tool/reviewer capability. Reading an old playback claim is `metadata` with attribution, not newly performed listening.

`findings` rows:

```json
{"id":"F1","dimension":"opening","location":{"output":null,"source":null,"locator":"opening caption"},"observation":"Concrete statement supported by E1","evidence_ids":["E1"],"hypothesized_viewer_response":"Possible confusion about who is speaking","confidence":"low","confidence_reason":"Text only; delivery unknown","severity":"material","remedy":"Inspect the opening with sound, then clarify the speaker if needed"}
```

Confidence (`low`, `medium`, `high`) describes support for the editorial hypothesis, not certainty about audience behavior. Severity is `minor`, `material`, or `critical`; critical means missing meaning/payoff or another prerequisite to a usable clip, not predicted loss of views. Include positive/protected observations when needed to prevent a damaging trim. `unknowns` rows are `{ "question": "...", "needed_evidence": "...", "next_action": "...", "blocks": "specific decision, or none" }`.

Each `assessment` member uses `{ "level": "unknown", "reason": "...", "evidence_ids": [] }`. Anchors:

| Dimension | Allowed levels and anchors |
|---|---|
| retention_risk | `unknown`; `low`: inspected narrative understandable with no material break; `moderate`: a localized clarity/pacing concern; `high`: promise, causality, or payoff materially undermined |
| sharing_potential | `unknown`; `limited`: no specific recipient/reason identified; `plausible`: an identifiable audience has a concrete reason to share; `strong`: that reason is distinct and supported by inspected content |
| brand_destination_fit | `unknown`; `weak`: mismatched audience/promise; `partial`: brand fits but destination relevance or route remains unresolved; `strong`: authentic moment and supported relevant destination |
| evidence_coverage | `metadata_only`, `transcript_only`, `partial_av`, `full_av`; describe source-context and analytics coverage separately in the reason |
| technical_readiness | `unknown`, `issues_found`, `checks_passed`; this summarizes cited checks only, never listening or release approval |

Do not combine these into a total or a virality score. Unknown is not zero. Full AV coverage alone does not verify factual claims, destination routes, or analytics.

## Edit plan and analytics

`edits` rows:

```json
{"id":"P1","priority":1,"finding_ids":["F1"],"action":"inspect_then_rewrite","current_location":{"source":null,"output":null,"locator":"opening"},"proposed":{"source_ranges":[],"output_range":null,"hook_text":null,"title":null,"caption":null,"instructions":"Specific proposed change"},"protect":["complete first thought"],"mechanism":"Why this may improve comprehension","effort":"small","tradeoff":"Potential loss or recovery cost","verification":"Concrete inspection of the changed result","ready_for_implementation":false}
```

Effort is `small`, `medium`, or `large`, with context in `tradeoff`. Set ready true only when the needed evidence/boundaries exist. It is not permission to execute. For holds/reframes/censors, give exact verified range and placement when available; otherwise specify the inspection needed. Proposed text must be literal copy, not “make the hook stronger.”

`protected_moments` rows contain `description`, `source`, `output`, and `evidence_ids`. `cta` records exact text, destination, route and verification evidence, proposed output window, and any timing exception. If duration is unresolved, keep the window null and explain its derivation in `timing_reason`.

`measured_metrics` rows contain `name`, `value`, `unit`, `definition`, `numerator`, `denominator`, `observation_window`, `platform_post_id`, `revision_binding`, `evidence_ids`, and `limitations`. Missing counts stay null, with a limitation; never reverse-engineer them from rounded rates. Distinguish average watch duration from completion, unique viewers from plays, and share counts from share rates. Store observed curve points only with their exported definitions/timebase. Do not interpolate a fictional curve.

`experiment` contains one variable, proposed variants, hypothesis, observation window, metrics with availability/definition, and attribution/confounding limits. Destination metrics may be tracked route clicks or attributable visits if actually available; profile visits alone do not prove Twitch/YouTube arrivals, and new follows do not prove paid conversion. If data cannot support a comparison, state the collection needed and leave the experiment unrun. An observation window is a plan, not a fabricated performance threshold.

## Production handoff

The editor translates accepted recommendations into strategy.json: premise/audience/payoff, source-time keep ranges and caption_cues/audio_censors, output-time hook/cta, protected_moments and notes. Run plan to regenerate storyboard.json/render-edl.json after structural changes. Render a new revision and verify the actual export. The sidecar never grants edit/publication authorization or marks listening approval. The portable helper does not automatically consume the retention report; the coding agent interprets it.

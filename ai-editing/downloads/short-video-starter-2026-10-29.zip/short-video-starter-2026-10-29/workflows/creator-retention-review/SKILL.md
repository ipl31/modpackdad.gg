---
name: creator-retention-review
description: Review a short-video candidate or revision for opening clarity, attention risks, sharing potential, and a relevant next step; create an evidence-bound optimization plan without editing or publishing.
---

Read settings.json, the exact candidate/revision, available source context, transcript and edit map. Bind findings to the actual media path/hash and correct source/output clocks. Review the first frame and first 1–3 seconds, then setup, escalation, complete payoff, readability, rhythm, authenticity and destination relevance.

Produce retention-review.json from assets/retention-review.template.json and a plain-language top-five optimization plan. Each finding needs an observation, evidence/time range, hypothesis, confidence, practical change and verification. Separate sampled pictures, transcript reading and actual visual playback/listening; no tool score implies human perception. Unknown is not zero. Read references/output-contract.md when filling the report.

Ask: Is there immediate visible proof of the premise? A specific reason this viewer cares? A reason to stay for the next beat? Does the payoff deliver the promise here? Would someone who enjoyed this actually want the named destination? Give literal hook/overlay alternatives grounded in the footage. Prefer one primary next step; do not manufacture dialogue, reactions, events, live status or misleading cliffhangers.

Editorial ratings prioritize effort, not predicted views or guaranteed virality. Do not combine unknowns into a confident total. Real analytics belong in a separate measured section with post/revision identity, duration, paid/organic context, denominators, observation windows and attribution limits. A completion drop is evidence of where interest falls, not proof of why. Suggest one small experiment; do not claim sequential posts are controlled A/B tests.

A review-only request ends with a plan. An authorized edit is handed to creator-shortform; refresh review after changes to story/pacing, and target changed moments for cosmetic fixes. Never write playback approval or publication permission into a report.

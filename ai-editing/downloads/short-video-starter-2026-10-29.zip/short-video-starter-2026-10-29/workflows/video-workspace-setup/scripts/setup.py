"""Read-only environment discovery and neutral configuration initialization. No installation or uploads."""
import argparse,importlib.util,json,os,platform,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def config():
 p=ROOT/'settings.json'
 return json.loads((p if p.exists() else ROOT/'settings.example.json').read_text(encoding='utf-8'))
def validate(d):
 c,e,p=d['creator'],d['editing'],d['processing']
 assert p['local_only'] is True,'This starter supports local-only processing.'
 assert e['platform'] in ['tiktok','youtube-shorts','instagram-reels']
 assert e['profanity'] in ['preserve','bleep','ask']
 assert e['caption_preference'] in ['when_available','off','required']
 assert isinstance(e['language'],str) and e['language'].strip()
 for k in ['width','height']:assert isinstance(p[k],int) and 240<=p[k]<=3840 and p[k]%2==0,'Use even export dimensions between 240 and 3840.'
 assert isinstance(p['threads'],int) and 1<=p['threads']<=32
 assert isinstance(p['workspace'],str) and p['workspace'].strip()
 for k in ['ffmpeg','ffprobe']:assert isinstance(p[k],str) and p[k].strip()
 if c['logo']:assert Path(c['logo']).expanduser().is_file() or (ROOT/c['logo']).is_file(),'The supplied logo path is unavailable.'
 color=e['accent_color'];assert len(color)==7 and color[0]=='#' and all(x in '0123456789abcdefABCDEF' for x in color[1:]),'Use a hex color such as #44CCDD.'
 return True
def doctor():
 d=config();p=d['processing'];tools={}
 for name in ['ffmpeg','ffprobe']:
  exe=shutil.which(p[name]);row={'available':bool(exe)}
  if exe:
   r=subprocess.run([exe,'-version'],capture_output=True,text=True,timeout=15);row['version']=r.stdout.splitlines()[0] if r.stdout else 'unknown';row['usable']=r.returncode==0
   if name=='ffmpeg':row['subtitles_filter']='subtitles' in subprocess.run([exe,'-hide_banner','-filters'],capture_output=True,text=True,timeout=15).stdout
  tools[name]=row
 cuda=None
 if shutil.which('nvidia-smi'):
  try:cuda=subprocess.run(['nvidia-smi','--query-gpu=name','--format=csv,noheader'],capture_output=True,text=True,timeout=10).returncode==0
  except subprocess.SubprocessError:cuda=False
 return {'python':platform.python_version(),'os':platform.system(),'tools':tools,'faster_whisper_installed':importlib.util.find_spec('faster_whisper') is not None,'gpu_driver_detected':cuda,'gpu_runtime_verified':False,'local_only':True,'setup_complete':False,'note':'Hardware identity is not recorded. Driver detection alone does not establish usable transcription acceleration.'}
def main():
 a=argparse.ArgumentParser();a.add_argument('command',choices=['doctor','init','validate']);args=a.parse_args()
 if args.command=='init':
  dest=ROOT/'settings.json'
  if not dest.exists():shutil.copyfile(ROOT/'settings.example.json',dest)
  print('settings.json is ready; existing answers were preserved.');return
 if args.command=='validate':validate(config());print('Configuration valid. Tools/source still need checking.');return
 report=doctor();print(json.dumps(report,indent=2));workspace=Path(config()['processing']['workspace']).expanduser();workspace=workspace if workspace.is_absolute() else ROOT/workspace;workspace.mkdir(parents=True,exist_ok=True);(workspace/'setup-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':
 try:main()
 except (AssertionError,KeyError,ValueError,OSError,subprocess.SubprocessError) as e:print('Setup needs attention:',str(e),file=sys.stderr);sys.exit(1)

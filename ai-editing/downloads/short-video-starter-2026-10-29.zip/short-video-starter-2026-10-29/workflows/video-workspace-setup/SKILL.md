---
name: video-workspace-setup
description: Bootstrap the portable short-video starter kit for a new creator, inspect local editing tools, collect a small set of preferences, and produce a first review clip. Use for first-run setup or repairing this kit's environment.
---

Read the package START-HERE.md and run `python workflows/video-workspace-setup/scripts/setup.py doctor` with an available Python 3 interpreter. If Python is unavailable, explain the single required installation step in plain language and continue collecting preferences. Do not assume an OS, home directory, graphics card, network worker, paid service, or account connection. Prefer one local computer; no remote addresses come configured.

Ask this first-run batch in friendly language, accepting “use defaults” or “skip” for optional details:

1. Which video should we start with? A local file path is enough. If they give a folder, ask which file or get permission to inventory that folder; do not scan unrelated drives.
2. What name should appear, who are the clips for, and what should they feel like? Logo/colors are optional; neutral styling works without them.
3. Is the first destination TikTok, YouTube Shorts, or Instagram Reels, and is there one channel/link you want to mention? A destination link is optional.
4. What language are you speaking, do you want captions, and should strong language stay or be bleeped? Defaults: English, captions when available, preserve original language until they choose censorship.
5. May we transcribe on this computer and install any missing free local tools in this workspace? Default: local-only processing; explain tools/downloads before installing. Declining installation is fine: use available tools or clearly identify the remaining step. Never treat silence as approval to install or upload.

Do not ask for passwords, API keys, IP addresses, exact hardware specifications, physical location, or a time zone for editing. Discover OS/tools and optional accelerators with the doctor. Do not infer CUDA compatibility solely from a detected GPU; use CPU if necessary. If the user supplies only a video, proceed with a neutral draft after confirming the few choices that affect privacy or meaning.

Write user answers to `settings.json` using settings.example.json as the schema; keep skipped brand/link fields empty. Paths come from the receiving user, never from examples. Validate with `setup.py validate`. The file and all runtime outputs are ignored by Git and excluded from redistribution. Record tool status and genuinely completed steps in `workspace/setup-report.json`. Set setup_complete true only after validating the saved answers, verifying the chosen source and required tools, and recording any optional missing capabilities. Do not repeat the first-run questionnaire on a configured workspace; ask only what is still missing. Do not label setup complete when dependencies or the source are missing.

Install missing dependencies only within the user's authorization. Prefer a workspace virtual environment for Python dependencies; commands differ by OS. FFmpeg/ffprobe need executables on PATH; burning captions requires the subtitles filter. Optional local faster-whisper transcribes; model downloads require internet but do not upload media. This bundle includes neither binaries nor model weights. A basic edit can proceed without transcription when captions aren't requested or an accurate existing transcript is available. Read [setup troubleshooting](../../SETUP.md) in the source checkout; in an exported package use root SETUP.md.

Then read creator-shortform/SKILL.md, inspect the actual source, and prepare a small first review clip. Do not stop at a setup checklist when editing is authorized. Preserve the original, explain missing capabilities simply, and give the user an actual playable output plus how to request revisions. File-based routing works without global skill installation. If the user wants global skill registration, use their agent's installed skill manager; never overwrite existing skills or global instructions during bootstrap.

"""Portable local short-video baseline. Originals are read-only; no accounts, shell commands or uploads."""
import argparse,datetime,hashlib,json,math,re,shutil,subprocess,sys,html
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def settings():
 p=ROOT/'settings.json'
 if not p.exists():raise ValueError('Run first-time setup to create settings.json before editing.')
 return read(p)
def workspace():
 p=Path(settings()['processing']['workspace']).expanduser();return p if p.is_absolute() else ROOT/p

def run(cmd,cwd=None):
 r=subprocess.run([str(x) for x in cmd],cwd=cwd,capture_output=True,text=True)
 if r.returncode:raise ValueError('Command failed: '+str(cmd[0])+'\n'+r.stderr[-2500:])
 return r.stdout

def probe(p):return json.loads(run([settings()['processing']['ffprobe'],'-v','error','-show_streams','-show_format','-of','json',p]))
def source(j):
 c=read(j/'candidate.json');p=Path(c['source'])
 if not p.is_file():raise ValueError('Original source is unavailable. Restore it or import its new path as a new job.')
 if sha(p)!=c['sha256']:raise ValueError('Original changed; import it as a new job instead of reusing this edit.')
 return c

def intake(path,slug):
 if not re.fullmatch('[a-z0-9][a-z0-9-]{0,79}',slug):raise ValueError('Use a short lowercase clip ID with letters, numbers and hyphens.')
 src=Path(path).expanduser().resolve();info=probe(src);v=next((x for x in info['streams'] if x['codec_type']=='video'),None)
 if not v:raise ValueError('The selected file has no video stream.')
 if not any(x['codec_type']=='audio' for x in info['streams']):raise ValueError('This starter expects an audio track; author silent footage separately.')
 j=workspace()/'projects'/slug;digest=sha(src)
 if (j/'candidate.json').exists():
  if read(j/'candidate.json')['sha256']!=digest:raise ValueError('Clip ID already belongs to different footage.')
  source(j);print(j);return
 j.mkdir(parents=True,exist_ok=True);duration=float(info['format']['duration']);save(j/'candidate.json',dict(id=slug,source=str(src),sha256=digest,probe=info))
 save(j/'strategy.draft.json',dict(premise='',audience='',opening_options=[],payoff='',keep=[dict(source_in=0,source_out=duration,purpose='Replace with inspected selection')],crop=None,captions='none',caption_cues=[],hook=dict(text='',start=0,end=min(2,duration)),cta=dict(text='',start=max(0,duration-4),end=duration),audio_censors=[],protected_moments=[],notes=[],boundary_resolutions=[]))
 print(j)

def transcribe(j,model,device):
 c=source(j);d=settings();out=j/'transcript.json';cache=dict(source_sha256=c['sha256'],model=model,device=device,language=d['editing']['language'])
 if out.exists() and read(out).get('settings')==cache:print('Reused local transcription.');return
 try:from faster_whisper import WhisperModel
 except ImportError:raise ValueError('Local transcription is not installed in this Python environment. See SETUP.md; no cloud fallback was used.')
 wav=j/'transcription.wav';run([d['processing']['ffmpeg'],'-v','error','-y','-i',c['source'],'-vn','-ac','1','-ar','16000',wav])
 m=WhisperModel(model,device=device,compute_type='int8' if device=='cpu' else 'float16',cpu_threads=d['processing']['threads'],num_workers=1)
 segments,info=m.transcribe(str(wav),language=d['editing']['language'],word_timestamps=True);rows=[];words=[]
 for s in segments:
  rows.append(dict(start=s.start,end=s.end,text=s.text));words.extend(dict(start=w.start,end=w.end,text=w.word.strip()) for w in s.words or [])
 save(out,dict(settings=cache,segments=rows,words=words,timing='Local ASR estimates; not forced alignment or listening approval.'));print(out)

def bounded(start,end,duration):
 if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in [start,end]):raise ValueError('Times must be finite numbers.')
 if not 0<=start<end<=duration+.001:raise ValueError('Time range lies outside its media or is empty.')

def plan(j):
 c=source(j);p=read(j/'strategy.json');d=settings();parts=[];clock=0;previous=-1;duration=float(c['probe']['format']['duration'])
 if not p.get('premise') or not p.get('payoff'):raise ValueError('Author the premise and complete payoff before rendering.')
 if not p.get('keep'):raise ValueError('Select at least one source range.')
 for b in p['keep']:
  lo,hi=b['source_in'],b['source_out'];bounded(lo,hi,duration)
  if lo<previous:raise ValueError('Source ranges must be chronological and nonoverlapping; document custom rearrangements in a custom composition.')
  frames=max(1,math.floor((hi-lo)*30+.5));dur=frames/30;parts.append(dict(source_in=lo,source_out=hi,output_in=clock,output_out=clock+dur,frames=frames,duration=dur,purpose=b['purpose']));clock+=dur;previous=hi
 if p['captions'] not in ['none','existing','authored']:raise ValueError('Invalid caption policy.')
 if d['editing']['caption_preference']=='required' and p['captions']=='none':raise ValueError('Captions were requested; supply authored captions or confirm usable existing captions.')
 if p.get('audio_censors') and p['captions']=='existing':raise ValueError('Bleeping needs matching embedded-text correction; use clean footage/authored captions or a custom repair first.')
 captions=[];censors=[]
 for key,out in [('caption_cues',captions),('audio_censors',censors)]:
  for cue in p.get(key,[]):
   lo,hi=cue['start'],cue['end'];bounded(lo,hi,duration);matches=[b for b in parts if b['source_in']<=lo<hi<=b['source_out']]
   if len(matches)!=1:raise ValueError(key+' must fit entirely in one retained source range; split or remove excluded cues explicitly.')
   b=matches[0];end=min(b['output_in']+hi-b['source_in'],b['output_out']);out.append(dict(cue,start=b['output_in']+lo-b['source_in'],end=end))
 if p['captions']=='authored' and not captions:raise ValueError('Authored captions require corrected source-time caption cues.')
 if p.get('audio_censors') and p['captions']=='authored' and not p.get('censored_caption_reviewed'):raise ValueError('Confirm censored caption wording in the authored cues before rendering.')
 for key in ['hook','cta']:
  cue=p.get(key,{})
  if cue.get('text'):bounded(cue['start'],cue['end'],clock)
 if p.get('cta',{}).get('text') and not d['creator']['destination_url']:raise ValueError('A channel invitation needs a user-supplied destination; otherwise leave the CTA empty.')
 crop=p.get('crop');v=next(x for x in c['probe']['streams'] if x['codec_type']=='video')
 if crop:
  if any(float(x.get('rotation',0))%360 for x in v.get('side_data_list',[])) or float(v.get('tags',{}).get('rotate',0))%360:raise ValueError('Prepare rotated footage before explicit pixel crops.')
  x,y,w,h=[crop[k] for k in ['x','y','width','height']]
  if not all(isinstance(z,int) for z in [x,y,w,h]) or min(x,y)<0 or min(w,h)<=0 or x+w>v['width'] or y+h>v['height']:raise ValueError('Crop exceeds the source frame.')
 flags=[];transcript=j/'transcript.json'
 if transcript.exists():
  for b in parts:
   for w in read(transcript).get('words',[]):
    if w['start']<b['source_in']<w['end'] or w['start']<b['source_out']<w['end']:flags.append(w)
 if flags and not p.get('boundary_resolutions'):raise ValueError('Cuts cross ASR word estimates. Listen/adjust or document specific boundary_resolutions before continuing.')
 result=dict(source_sha256=c['sha256'],strategy_sha256=sha(j/'strategy.json'),settings_sha256=sha(ROOT/'settings.json'),duration=clock,parts=parts,caption_cues=captions,audio_censors=censors,asr_boundary_flags=flags,full_av_review=False)
 save(j/'render-edl.json',result);save(j/'storyboard.json',dict(result,premise=p['premise'],payoff=p['payoff'],protected_moments=p.get('protected_moments',[]),notes=p.get('notes',[])));return result

def asstime(t):
 cs=round(t*100);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
def ass_escape(text):return str(text).replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\n','\\N').replace('\r','')
def write_ass(out,p,edl,d):
 w,h=d['processing']['width'],d['processing']['height'];font=d['editing']['font_family'].replace(',',' ');accent=d['editing']['accent_color'];color='&H00'+accent[5:7]+accent[3:5]+accent[1:3]
 styles='\n'.join(f'Style: {name},{font},{size},{col},&H000000FF,&H00111111,&H88000000,0,0,0,0,100,100,0,0,3,2,0,{align},{round(w*.09)},{round(w*.13)},{margin},1' for name,size,col,align,margin in [('Caption',round(h*.032),'&H00FFFFFF',2,round(h*.25)),('Hook',round(h*.042),color,8,round(h*.08)),('CTA',round(h*.029),'&H00FFFFFF',2,round(h*.14))])
 events=[]
 for name,cues in [('Hook',[p.get('hook',{})]),('CTA',[p.get('cta',{})]),('Caption',edl['caption_cues'] if p['captions']=='authored' else [])]:
  for c in cues:
   if c.get('text'):events.append(f'Dialogue: 0,{asstime(c["start"])},{asstime(c["end"])},{name},,0,0,0,,{ass_escape(c["text"])}')
 text=f'[Script Info]\nScriptType: v4.00+\nPlayResX: {w}\nPlayResY: {h}\nWrapStyle: 0\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n{styles}\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'+'\n'.join(events)+'\n'
 out.write_text(text,encoding='utf-8');return bool(events)

def render(j,revision):
 if not re.fullmatch('r[0-9]{2,4}',revision):raise ValueError('Use a revision such as r01.')
 edl=plan(j);c=source(j);p=read(j/'strategy.json');d=settings();cfg=d['processing'];out=workspace()/'outputs'/c['id']/revision
 if out.exists():raise ValueError('Revision already exists; choose a new revision. Failed partial exports can be inspected before removal.')
 out.mkdir(parents=True);(out/'.incomplete').touch();ff=cfg['ffmpeg'];threads=str(cfg['threads']);w,h=cfg['width'],cfg['height'];units=[]
 for i,b in enumerate(edl['parts']):
  target=out/f'beat-{i:03}.mov';crop=p.get('crop');vf=(f'crop={crop["width"]}:{crop["height"]}:{crop["x"]}:{crop["y"]},' if crop else '')+f'scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=0x17191b,setsar=1,fps=30,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={b["frames"]},setpts=N/30/TB'
  af=f'aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,apad,atrim=duration={b["duration"]},asetpts=N/SR/TB'
  run([ff,'-v','error','-y','-threads',threads,'-ss',b['source_in'],'-t',b['duration']+.1,'-i',c['source'],'-vf',vf,'-af',af,'-c:v','libx264','-threads',threads,'-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','pcm_s16le','-t',b['duration'],target]);units.append(target)
 listing=out/'units.ffconcat';listing.write_text(''.join("file '"+x.name+"'\n" for x in units),encoding='utf-8');run([ff,'-v','error','-y','-f','concat','-safe','0','-i',listing.name,'-c','copy','joined.mov'],cwd=out)
 overlays=write_ass(out/'overlays.ass',p,edl,d);vf='subtitles=overlays.ass' if overlays else 'null';inputs=['-i','joined.mov'];filters=[];video='vbase';filters.append(f'[0:v]{vf}[vbase]')
 logo=d['creator'].get('logo')
 if logo:
  lp=Path(logo).expanduser();lp=lp if lp.is_absolute() else ROOT/lp
  inputs+=['-i',str(lp.resolve())];filters+= [f'[1:v]scale={round(w*.1)}:-1[logo]',f'[vbase][logo]overlay={round(w*.04)}:{round(h*.03)}:eof_action=repeat[vlogo]'];video='vlogo'
 audio='a0';filters.append('[0:a]anull[a0]')
 for i,censor in enumerate(edl['audio_censors']):
  lo,hi=censor['start'],censor['end'];expr=f'between(t,{lo},{hi})';filters.append(f'[{audio}]volume=0:enable=\'{expr}\'[mute{i}]');filters.append(f'sine=frequency=1000:sample_rate=48000:duration={edl["duration"]},volume=0.12:enable=\'{expr}\',volume=0:enable=\'not({expr})\',aformat=channel_layouts=stereo[tone{i}]');filters.append(f'[mute{i}][tone{i}]amix=inputs=2:duration=first:normalize=0[a{i+1}]');audio=f'a{i+1}'
 run([ff,'-v','error','-y','-threads',threads,*inputs,'-filter_complex_threads',threads,'-filter_complex',';'.join(filters),'-map',f'[{video}]','-map',f'[{audio}]','-c:v','libx264','-threads',threads,'-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-t',edl['duration'],'-movflags','+faststart','episode.mp4'],cwd=out)
 info=probe(out/'episode.mp4');v=next(x for x in info['streams'] if x['codec_type']=='video');expected=sum(b['frames'] for b in edl['parts'])
 if int(v['nb_frames'])!=expected:raise ValueError('Frame count mismatch; inspect the partial revision.')
 run([ff,'-v','error','-threads',threads,'-i',out/'episode.mp4','-map','0:v','-map','0:a','-f','null','-'])
 report=dict(revision=revision,sha256=sha(out/'episode.mp4'),source_sha256=c['sha256'],duration=float(info['format']['duration']),video_frames=expected,width=v['width'],height=v['height'],full_decode=True,full_visual_playback=False,listening=False,editorial_approval=False,published=False,status='awaiting_playback_review')
 save(out/'review.json',report);save(out/'render-edl.json',edl);shutil.copy2(j/'strategy.json',out/'strategy.json');shutil.copyfile(ROOT/'workflows/creator-shortform/assets/review.html',out/'review.html');(out/'.incomplete').unlink();print(out/'episode.mp4')

def main():
 a=argparse.ArgumentParser();s=a.add_subparsers(dest='command',required=True);p=s.add_parser('intake');p.add_argument('source');p.add_argument('--id',required=True)
 for cmd in ['plan','transcribe','render']:
  p=s.add_parser(cmd);p.add_argument('job',type=Path)
  if cmd=='render':p.add_argument('--revision',required=True)
  if cmd=='transcribe':p.add_argument('--model',default='small');p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
 args=a.parse_args()
 if args.command=='intake':intake(args.source,args.id)
 elif args.command=='transcribe':transcribe(args.job.resolve(),args.model,args.device)
 elif args.command=='plan':print(json.dumps(plan(args.job.resolve()),indent=2))
 else:render(args.job.resolve(),args.revision)
if __name__=='__main__':
 try:main()
 except (ValueError,KeyError,OSError,StopIteration) as e:print('Editing needs attention:',str(e),file=sys.stderr);sys.exit(1)

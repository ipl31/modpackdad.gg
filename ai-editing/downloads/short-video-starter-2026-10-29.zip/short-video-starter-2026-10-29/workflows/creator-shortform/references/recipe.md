# Short-video recipe

Specific hook → minimum context → escalation → complete payoff → one relevant invitation.

Find the ending first. A strong clip is understandable to a stranger, makes one honest promise, and resolves it. Timing follows the material: a quick joke and a useful demonstration need different lengths. Start with interesting footage/speech; a text question is fine without new voice recording. Avoid a generic intro or static logo bumper before the reason to watch.

Useful patterns:

- Humor: setup → resistance/misunderstanding → punchline → genuine reaction.
- Gameplay/performance: goal → attempt → reversal/outcome → what makes the moment distinctive.
- Story/community: specific incident → concrete example → realization → complete resolution.
- Tutorial: question/problem → visible demonstration → bounded, factual takeaway.

For each clip record audience, premise, truthful promise, two opening options, required context, protected words/pauses, payoff, and one optional next step. Candidate triage can score brand fit, next-step fit, payoff, hook, standalone clarity and distinctive evidence 0–4 with written reasons. This is an editorial work queue; no total predicts virality.

Show visible evidence early rather than putting unrelated action behind an abstract headline. Keep a high hook separate from a single speech-caption layer. Use at most one emphasis at a time; effects need to clarify evidence or land an existing joke. The simple default card has a heading and main message, without an extra footer. These are starter choices, configurable for the creator.

Preserve complete thoughts and genuine pauses. Do not cut off the last word because ASR reports an early ending. If the provider clip is already clipped, recover the original context before editing; a frozen frame cannot restore lost speech. Match profanity edits in both sound and displayed text only when requested. Preserve user corrections by source time, not as universal substitutions.

Check source resolution before enlarging a face. Inspect leaning/motion and scene changes, not one static frame. For separate recordings, waveform clock alignment does not prove each embedded camera's lip sync; check speakers independently and use direct sources where appropriate.

Use the creator's supplied identity/assets, or neutral typography and colors. Do not redraw a missing logo as though it were official. A destination invitation should explain a real related benefit, not just list social accounts. A useful starting point is a short invitation over the closing few seconds, clear of captions and payoff; omit it when no relevant destination is supplied. Never trim speech or add a long frozen end card to meet a fixed ad duration. Verify links and any “full video,” “live now,” schedule or bio claims before using them.

Learn from comparable real posts: opening drop-off, average watch duration, completion, meaningful comments/shares and attributable destination visits. Keep paid promotion separate from organic traffic. Missing metrics remain unknown. Change one main variable at a time and retain the actual revised media identity. No universal posting time or algorithm threshold is assumed.

# Short Video Starter

Turn your own recordings into TikTok, YouTube Shorts or Instagram Reels review clips with a coding agent. No channel account, paid editing service or special graphics card is required for the basic workflow. You need a coding agent with access to local files and commands; access to that agent may have its own cost.

1. Extract the ZIP into a new folder. Keep the files together.
2. Open that folder as a project in Codex, Claude Code, OpenCode or another local coding agent.
3. Paste this:

> Read START-HERE.md and AGENTS.md. Use the video-workspace-setup skill to ask me the five first-run questions, check this computer, and help me create my first short video. I am a beginner: explain any missing tools simply and guide me one step at a time. Do not upload my recordings or publish anything. After setup, use creator-shortform and creator-retention-review to make a playable first review clip from the video I choose.

The agent should ask which recording to use, your optional name/style, the target platform/channel, language/captions/profanity preferences, and permission for local transcription or missing-tool installation. It detects tools itself. You can say “use defaults” or “skip” for optional details. It should continue through a real first clip rather than just return a checklist.

A ZIP does not run itself or automatically register skills. Opening the extracted project and sending the prompt starts setup. If a chat cannot access files or run local commands, use a local coding-agent workspace or follow its file-access instructions; attaching the archive alone may not provide an editing runtime.

The neutral package has no creator logo, account access, private footage, personal editing history or preconfigured remote machine. FFmpeg and optional transcription software/models are installed separately with your consent. SETUP.md explains the few requirements.

When finished, the agent gives you episode.mp4 and review.html in workspace/outputs. Open the review page or MP4, note timestamps, and say what to change. Older revisions and your original recording are preserved. Captions and advanced effects need the corresponding local tools and actual review; this kit does not guarantee audience performance.

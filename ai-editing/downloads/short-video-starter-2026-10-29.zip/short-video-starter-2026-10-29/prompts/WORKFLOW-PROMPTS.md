# Reusable editing prompts

These are generic operational prompts. Replace bracketed inputs; no prior creator or machine setup is implied. Use the current model unless you explicitly choose another available reviewer.

## First run

Read START-HERE.md and AGENTS.md. Use video-workspace-setup to guide me through the five questions and tool checks, then make my first playable review clip. Explain missing tools simply. Keep recordings local and do not publish.

## Candidate triage

Use creator-shortform and creator-retention-review on [supplied files]. Inspect enough context to find a complete premise and payoff. Identify candidates by content hash/provider ID, check any available posted notes, and rank editorial priority by brand fit, next-step relevance, payoff, opening, standalone clarity and distinctive evidence. Show source times and unknowns. Scores are work priorities, not predicted views.

## Detailed retention review

Review [exact clip/revision] as a short-video content editor. Give the top five changes that could improve the opening hook, visual attention, reason to stay, complete payoff and relevant channel interest. Bind observations to media identity and timestamps. Distinguish actual playback/listening, sampled pictures, transcripts and real analytics. Give two specific opening options and one recommended plan. Do not invent performance percentages or claim mastery of a platform algorithm. Do not edit or publish from this review-only request.

## Storyboard and edit

Use the accepted review for [candidate] to author strategy.json and a source-to-output storyboard. Use my settings for identity, audience, assets, captions and profanity. Preserve complete thoughts, genuine reactions and the payoff. Keep one caption layer; separate the high hook from captions. Add only relevant effects with exact source/output times and provenance. Use one optional relevant destination invitation over closing speech without hiding the payoff or truncating words. Render a new review revision and preserve originals.

## Revision

For [revision], make [requested changes]. Read previous notes, corrected captions and protected moments. Preserve everything already approved unless this request changes it. Recalculate edit maps, caption/effect/CTA timing and review after structural changes. Inspect altered seams and the full ending, then deliver a new playable revision with accurate verification limits.

## Final review

Inspect the exact exported file with sound and at phone size where capability allows. Check first-frame clarity, safe text placement, camera coverage through motion, captions and corrections, complete words at every changed cut, bleep/text pairing, ending and optional destination. Verify hashes, streams, duration and frame count. State what you actually viewed/listened to; technical checks do not establish editorial approval. Do not publish.

## Learn from results

Use [real post identity, revision, duration, paid/organic context, views, average watch duration, completion, retention drops, comments, shares, follows and attributable visits]. Compare similar posts and keep missing metrics unknown. Suggest one small opening/structure experiment and an observation window. A drop-off tells us where viewers leave, not conclusively why; followers/profile visits do not prove cross-platform conversion. Do not infer audience identity by matching usernames.

## Improve the workflow

Review the feedback and conversations actually available for recent projects. Separate ongoing preferences, repeated errors, clip-specific requests and untested suggestions. Save reusable preferences and a short dated lesson, preserve original plans, and propose a small practical improvement. Do not imply access to unavailable history or adopt one clip's joke, logo, machine path or publishing habit as a default for everyone.

## Author a retention skill

Act as a short-video editor and skill author. Create a review/planning skill using the current production contracts and the receiving creator's settings. Require media/revision/timebase identity, an inspection inventory, timestamped evidence, qualitative attention risks, concrete edit recommendations, protected moments and measurable experiment options. Keep actual metrics separate from hypotheses; never fabricate virality predictions or listening. Include a machine-readable review template and a handoff into the editing skill. Validate the files; do not modify media or authorize publication.

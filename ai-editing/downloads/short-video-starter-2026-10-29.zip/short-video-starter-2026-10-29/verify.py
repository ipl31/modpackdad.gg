"""Verify distributed file hashes without executing editing code."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
try:
 m=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
 for item in m['files']:
  p=root/item['path'];assert p.resolve().is_relative_to(root.resolve()),'Unsafe manifest path'
  assert p.is_file() and not p.is_symlink(),'Missing or linked file: '+item['path']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],'Changed file: '+item['path']
 print('Distribution hashes verified. Personal settings and workspace outputs are intentionally outside this manifest.')
except (AssertionError,OSError,ValueError,KeyError) as e:print('Verification failed:',str(e),file=sys.stderr);sys.exit(1)

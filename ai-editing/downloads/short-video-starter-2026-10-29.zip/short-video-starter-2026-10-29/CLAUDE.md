Read AGENTS.md and START-HERE.md, then use the setup skill for first run.

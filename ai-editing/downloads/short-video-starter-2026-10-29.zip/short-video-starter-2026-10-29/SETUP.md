# Setup help

The coding agent should guide you. You do not have to know your graphics card, network address or encoder settings.

Required: Python 3.10 or newer, and FFmpeg plus ffprobe. These are separate executables; a Python package named ffmpeg is not a replacement. The agent checks PATH and the FFmpeg subtitles filter. A local Python virtual environment keeps optional transcription dependencies separate from your other projects.

Typical local setup after the user agrees:

- Windows: use an installed Python launcher or Python executable to create `.venv` with `python -m venv .venv`. Its interpreter is `.venv/Scripts/python.exe`.
- macOS/Linux: use `python3 -m venv .venv`. Its interpreter is `.venv/bin/python`. Some systems need their Python venv support installed first.
- With that interpreter, `-m pip install faster-whisper` adds optional local transcription. The first use downloads model weights; it does not upload the recording. CPU mode is the portable default. Do not promise GPU speed until the runtime actually works.
- Install FFmpeg using the user's existing OS package manager or the build options linked from the official FFmpeg download page, https://ffmpeg.org/download.html . Explain the selected installer/package before executing it; don't paste a remote install script blindly. If a tool cannot be installed, report that dependency clearly and continue useful planning.

Open a terminal in the extracted folder, or have the agent run:

```
python workflows/video-workspace-setup/scripts/setup.py doctor
python workflows/video-workspace-setup/scripts/setup.py init
```

Use the available Python command instead of `python` if needed. The first command reports what is present; the second creates neutral settings without overwriting an existing configuration. The agent fills settings.json from your answers and runs `setup.py validate`. No account login is involved.

Missing subtitles filter: plain cuts can still render without burned overlays, but text/captions need a FFmpeg build with libass or an explicitly implemented alternate renderer. Missing font: supply an installed family or let the agent choose a neutral available replacement, then inspect the text. No proprietary font or creator asset is bundled.

Missing source: choose a real local video. A website URL is not automatically a downloadable recording or permission to log in. Downloads and account connections can be configured separately. Mobile/cloud-only files must first be made available in the coding workspace.

If you request captions without transcription, use a corrected existing transcript or explicitly choose a first draft without captions; the agent must not silently ignore required captions. Existing burned captions can be retained without adding another layer. Transcripts/timestamps still need review for names, punctuation and clipped word tails.

Your settings, reports, transcripts and clips stay under settings.json/workspace and are excluded from a fresh distribution ZIP. Do not share your personalized working folder as though it were the neutral starter; build a new sanitized package from the maintained source instead. Do not put credentials in settings.json.

Dependency references: [FFmpeg downloads](https://ffmpeg.org/download.html), [FFmpeg subtitles filter](https://ffmpeg.org/ffmpeg-filters.html#subtitles-1), and [faster-whisper installation and CPU/GPU examples](https://github.com/SYSTRAN/faster-whisper). Check these official project instructions when resolving platform-specific installation issues.

# Short-video project routing

Read START-HERE.md first. If settings.json is missing or setup is incomplete, use workflows/video-workspace-setup/SKILL.md and ask its first-run questions. Detect the environment instead of assuming hardware, network access or paths. Do not scan unrelated directories.

Use workflows/creator-shortform/SKILL.md for short-video editing and workflows/creator-retention-review/SKILL.md for evidence-bound retention plans. Read the user's settings and saved workspace/preferences.md when present. Keep long-form editing separate.

Bootstrap is scoped to this extracted project. Do not replace global agent instructions, auto-install skills globally, connect accounts, upload media, publish, push code or use remote workers during setup. Local tool installation and transcription follow the user's setup answers. No passwords or API keys are needed for local-file editing. Account/download/publishing integrations are optional later work.

Keep originals and earlier exports. Do not label sampled frames, ASR or signal correlation as complete listening/playback. Preserve complete speech and meaning, and deliver a playable review export with honest remaining checks. Treat user preferences as configuration, never as assumptions inherited from the package author.

The code is a portable baseline, not a complete graphical editor. Use installed advanced media skills if available and relevant; otherwise implement requested custom effects explicitly and verify them. Start with a simple review edit to establish the user's style.
